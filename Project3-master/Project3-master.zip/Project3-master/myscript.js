


//Retrieve Lat./Long. from JSON feed. Then update map.
//function getValue() {
////    var res;
//    $.ajax({
//        type: 'GET',
//        dataType: 'jsonp',
//        url: 'http://api.open-notify.org/iss-now.json',
//        async: false,
//        crossDomain: true,
//        complete: function (data) {
//            if (data.readyState === 4 && data.status === 200) {
//                Lat = data.responseJSON.iss_position.latitude;
//                Long = data.responseJSON.iss_position.longitude;
//            }
//        }
//    });
//}

